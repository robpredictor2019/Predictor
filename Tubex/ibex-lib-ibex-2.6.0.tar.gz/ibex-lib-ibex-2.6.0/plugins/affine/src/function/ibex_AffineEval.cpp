/* ============================================================================
 * I B E X - ibex_AffineEval.cpp
 * ============================================================================
 * License     : This program can be distributed under the terms of the GNU LGPL.
 *               See the file COPYING.LESSER.
 *
 * Author(s)   : Jordan Ninin
 * Created     : April 08, 2013
 * ---------------------------------------------------------------------------- */


#include "ibex_AffineEval.h"
#include "ibex_Function.h"
//#include <stdio.h>

namespace ibex {



} // namespace ibex

